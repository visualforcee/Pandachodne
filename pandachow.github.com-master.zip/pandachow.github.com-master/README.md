#Personal blog
This website powered by [Jekyll-Bootstrap](http://jekyllbootstrap.com/) and themed by [Hooligan](https://github.com/dhulihan/hooligan), which is built on top of [Twitter Bootstrap](http://twitter.github.io/bootstrap/).

[MarkPad](http://code52.org/DownmarkerWPF/) (Windows) and [Mou](http://mouapp.com/) (OS X) are my faviouate Markdown editors in local, sometimes I prefer to use online editor, such as [Dillinger](http://dillinger.io/) and [Made](https://chrome.google.com/webstore/detail/made/oknndfeeopgpibecfjljjfanledpbkog?hl=en).

#About me

## I am a
Christian | Hefeier | Entry level programmer

## I love
Mathematics | Parallel Computing | Country and Rock | Photography

## Follow me @
[twitter](https://twitter.com/ailurus1991) | [douban](http://www.douban.com/people/ailurus1991/) | [github](https://github.com/pandachow)