---
layout: post
categories: technology
tagline: webOS Faenzar theme for Palm Pre3
tags: [webOS, Pre3]
---

近期zoopda上众多机油对各种主题的要求非常高。主题嘛，最主要、也是比重最大的，应当就是程序的图标了。由于自己的UI设计能力连半吊子水平都算不上，就索性拿Gnome下最流行的[faenza](http://gnome-look.org/content/show.php/Faenza?content=128143)一套图标来充数了，再加上一个transparent主题的透明launcher和系统状态栏，遂成新一代主题：Faenzar for Pre3.

---
主题制作工具使用的是Webos Theme Builder 3.0这个版本。对于这个工具，我需要吐槽：

所有图片都要一个个点进去啊！！！

有些系统图标需要自己写软件名的啊！！！

所有的icon和其他图片的文件的路径都要一个个填进去啊，遇上日历图标蛋都碎了啊！！！

对于256的图片还需要另外加进去啊！！！

总结一下就是，整个主题的成功超过50%的成分是靠人品和耐心，= =||

对于主题实现的过程，我只能说制作的过程要远远难于构思和画图标。但是，正如awei72所说的那样，只要第一个主题的框架构建好了之后，后续工作和以后的主题制作起来就会非常容易了。主题的已经上架zoopda原创收费软件/主题购买区，购买和下载[点此](http://bbs.zoopda.com/thread-143258-1-1.html)。当然了，这套主题同时还会有免费版本，区别在于免费版仅有子同软件的图标，下载[点此](http://bbs.zoopda.com/thread-142617-1-2.html)。

下一步准备修改来电界面的图标和系统状态栏的图标，电池和信号什么的。