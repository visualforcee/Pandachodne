---
layout: post
title: webOS小清新风格主题Transparent for Pre3
categories:
- technology
tags:
- webOS
- Pre3
---

第一次做主题，参考了很多帖子和博客。熟悉了很久webOS的系统文件路径和打包脚本。我终于也能自己做主题了，=..=

废话不多说，暂且为1.0.0版本，我希望后期能得到更多的反馈和bug，以便能完善。真机测试没有问题，适合rom为2.2.4的Pre3，其他版本正在考虑（其实是手头没别的型号了。

===04/04/2012===

* **版本:**1.0.0
* **支持:** Pre3, Rom: 2.2.4
* **安装:** preware/WQI安装，装完完全重启luna。
* **内容:** launcher透明，mojo2状态栏透明，mojo状态栏透明。
* **下载:** [连接@Zoopda](http://bbs.zoopda.com/forum.php?mod=viewthread&tid=141644&page=1#pid2614680)