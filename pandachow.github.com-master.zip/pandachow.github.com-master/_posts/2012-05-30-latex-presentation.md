---
layout: post
category : technology
tagline: Gave a talk about LaTeX.
tags : [LaTeX, Typesetting]
---

大三的时候闵老师看我参加数学建模比赛的时候用LaTeX排论文，跟我打趣地说道：小周你什么时候给协会的会员弄个LaTeX讲座吧，普及普及下。当时自然满口答应下来，只是没想到这个承诺是在临近毕业的时候兑现的。我没奢求看到海报的同学都过来，就算是协会成员也没要求到场，那样没什么意思。人不算多，不足两个班，不过已经超过我的意料了。对了，还要谢谢班里两位妹子的捧场。

讲的东西非常浅显，一来是因为对着一群没用过LaTeX的人讲2个小时的命令细节或者语法没有意义，二来时间太短。于是更多的是阐述LaTeX的优势所在，Word和LaTeX如何各司其职。不过后面的Q&A环节我感到意外的是一堆人围着我问MATLAB和数学建模比赛经验……好吧，LaTeX确实不如MATLAB魅力大……

幻灯片用的是新浪前端工程师[三水清](http://js8.in/)的JavaScript框架，比较简洁。

这是Presentation的地址：[http://1.latexslide.sinaapp.com/#cover](http://1.latexslide.sinaapp.com/#cover)

可能还有些错误和不当的地方，发现bug请斧正。