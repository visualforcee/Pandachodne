---
layout: post
categories: life
tagline: Feeling of my first mechanical keyboard
tags: [Mechanical Keyboard, Blue Switch, Das Keyboard]
---
一把顺手的键盘是每一位码农都希望拥有的，即便不是码农，一把好用舒适的键盘对于经常打字的人来说也是必不可少的。我当然也不例外啦，其实在国内的时候就一直非常想败一把，无奈考虑到这玩意都不轻，千里迢迢带过来实在是代价太大，索性决定到美国之后再买好了。如果没记错的话当初是在 [Noppoo choc mini](http://www.aliengu.com/archives/1032)、[Keycool 87](http://www.chiphell.com/thread-337721-1-1.html) 和 [Neo 87](http://www.chiphell.com/thread-366742-1-1.html) 的青轴中最亲睐 Neo 87。到美帝后败完了耳机和 Nexus 7 又开始打起了机械键盘的主意了，然后就是意外发现这东西居然比国内价格要高不少，让我一直非常不解且不爽，可以看[这里](http://panda0411.com/2012/09/09/one-month-at-US.html)。紧接着又开始后悔上个月 Das Keyboard 的 Back to school 活动没有下手，印象中是 Professional 的版本优惠20刀哇……T_T

---
今天败掉的不是上面的任何一款，而是 Das Ultimate 青轴，所谓 Ultimate，与 Professional 的版本主要差异就是键帽是无刻的。之所以选择 Das 而不是其他的牌子，完全是因为 Das 在青轴领域的名气实在是太大，之所以选择 Ultimate，则主要是为了装逼 >_<，当然我不否认无刻的键盘看起来更加舒服。至于手感这种因人而异的东西我就不多做评价了，个人角度来说这是我用过最享受的键盘，相比之下原来笔记本的键盘简直是噩梦，粘糊糊而且肉乎乎。实在不想回忆去年参加数学建模国赛最后改论文那恶心的一幕一幕……

---
![](/assets/files/2012/09/19/das-01.JPG)
镜面的材质实在是太让人喜欢了，BTW，这样也更容易收到划伤，也很容易粘灰尘（如图所示……
![](/assets/files/2012/09/19/das-02.JPG)
无刻的感觉实在是太棒了，右边是两个 USB HUB 口。
![](/assets/files/2012/09/19/lovely.JPG)
来一张起司喵的全身照吧！